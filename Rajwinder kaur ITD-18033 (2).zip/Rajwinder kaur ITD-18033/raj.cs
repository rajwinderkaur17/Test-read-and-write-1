﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                string myFile;
                SaveFileDialog save = new SaveFileDialog();
                save.FileName = "";
                save.Filter = "Text File | *.text* | All files | *.*";
                save.InitialDirectory = Directory.GetCurrentDirectory();
                DialogResult result = save.ShowDialog();
                switch (result)
                {
                    case DialogResult.OK:
                        {
                            myFile = save.FileName;
                            textBox1.Text = myFile;
                            break;
                        }
                }

            }
            else if (radioButton2.Checked == true)
            {

                string myFile;

                OpenFileDialog obj1 = new OpenFileDialog();
                obj1.InitialDirectory = @"C:\\Users\\abc\\Desktop\\";
                if (obj1.ShowDialog() == DialogResult.OK)
                {
                    myFile = obj1.FileName;
                    textBox1.Text = myFile;
                    StreamReader file = new StreamReader(myFile);

                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[7] { new DataColumn("#"),
                    new DataColumn("Purchase-Date"), new DataColumn("Serial #")
                    ,new DataColumn("Manufacturing Tools"), new DataColumn("Price"),
                    new DataColumn("Qty"), new DataColumn("Amount")});


                    string newline;
                    while ((newline = file.ReadLine()) != null)
                    {
                        DataRow dr = dt.NewRow();
                        string[] values = newline.Split(',');
                        for (int i = 0; i < values.Length; i++)
                        {
                            dr[i] = values[i];
                        }
                        dt.Rows.Add(dr);
                    }
                   
                }


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string myfile = textBox1.Text;
            try
            {
                int tran = int.Parse(textBox2.Text);
                string d = textBox3.Text;
                string snum = textBox4.Text;
                string tool = textBox5.Text;
                string pr = textBox6.Text;
                int q = int.Parse(textBox7.Text);
                string ac = textBox8.Text;
                StreamWriter sm = new StreamWriter(myfile, true);
                string data = tran + "," + d + "," + snum + "," + tool + "," + pr + "," + q + "," + ac;
                sm.WriteLine(data);

                sm.Close();
                EmptyTextBoxes(this);

            }

            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void EmptyTextBoxes(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c.GetType() == typeof(TextBox))
                {
                    ((TextBox)(c)).Text = string.Empty;
                }
            }
        }

    }
}